<!DOCTYPE html>

<head></head>

<Body>
    <form action="login.php" method="post">
        <label>Username : </label>
        <input type="text" name="user"><br><br>
        <label>Password : </label>
        <input type="password" name="pass"><br>
        <input type="submit" value="Login">
    </form>
</Body>

</html>