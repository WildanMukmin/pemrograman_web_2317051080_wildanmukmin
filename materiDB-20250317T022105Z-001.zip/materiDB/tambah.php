<!DOCTYPE html>

<head></head>

<Body>
    <form action="tambah_exe.php" method="POST">
        <label for="fname">Nama:</label><br>
        <input type="text" name="nama"><br>
        <label for="lname">NPM:</label><br>
        <input type="text" name="npm"><br>
        <label for="lname">Alamat:</label><br>
        <input type="text" name="alamat"><br>
        <label for="lname">No Sepatu:</label><br>
        <input type="text" name="no_spt"><br>
        <input type="submit" value="tambah">
    </form>
</Body>

</html>